package restassuredtestcases;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;
import io.restassured.matcher.ResponseAwareMatcher;
import io.restassured.response.Response;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

public class ReqresEndToEndTesting {
	
	
@Test(priority = 1,enabled = true)	
public void endToEndTesting() {
		
		System.out.println("===============Test1=============");
// Register user		
		baseURI = "https://reqres.in/api";
		
	    JSONObject reqData = new JSONObject();
	    
        reqData.put("email", "eve.holt@reqres.in");
        reqData.put("password", "pistol");
        
        System.out.println(reqData.toJSONString());
        
        given()
            .header("Connection", "keep-alive")
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON)
            .body(reqData.toJSONString())
       .when()
            .post("/register")
        .then()
            .statusCode(200)
            .log().body();
        
//   >++++++++++++++++++Extract Register token++++++++++++++++<
        String token	=	given()
    		            .body(reqData.toJSONString())
                        .contentType(ContentType.JSON)
                        .accept(ContentType.JSON)
                         .header("Charset","utf-8")
                    .when()    
    		            .post("/register")
    	            .then()
    	                .extract().path("token");
    System.out.println("token : "+ token);


    int userID = given()
    		      .body(reqData.toJSONString())
                  .contentType(ContentType.JSON)
                  .accept(ContentType.JSON)
                  .header("Charset","utf-8")
             .when()    
                  .post("/register")
             .then()
                  .extract().path("id");
       System.out.println("id : "+ userID);
       
//     >++++++++++++++++++++User Login+++++++++++++++< 
     		given()
     			.header("Content-Type","application/json")
     			.header("Connection","keep-alive")
     			.accept(ContentType.JSON)
     			.body(reqData.toJSONString())
     		.when()
     				.post("/login")
     		.then()
     		//verify status code 
     		.statusCode(200)
     		.log().body()
     		.log().headers()
     		.log().all();
     		
 //    >++++++++++Extract login token+++++++++++++<
     		String logintoken =  given()	
     				.body(reqData.toJSONString())
     				.contentType(ContentType.JSON)
     				.accept(ContentType.JSON)
     				.header("charset","utf-8")
     			.when()
     				.post("/login")
     			.then()
     				.extract().path("token");
     		System.out.println("TOKEN : " + logintoken);
     		
//   >+++++++++++++++++get single user++++++++++++++++++++<
     		given()
     			.get("/users/" + userID)
     	   .then()
     			.statusCode(200)
     			.body("data.id", equalTo(4))
     			.body("data.last_name", equalTo("Holt"))
     			.log().headers()
     			.log().body();
     		
//    >++++++++++++++++++++SINGLE <RESOURCE>  user id and validate details+++++++++++++<
     		given()
     			.get("/unknown/" +userID)
     	   .then()
     			.statusCode(200)
     			.body("data.id",equalTo(4) )
     			.body("data.name", equalTo("aqua sky"))
     			
     			.log().all();
     		
//       >+++++++++++++++++patch same user >> validate response >> search user >> validate++++++++++++++++++<
     		
     		reqData.put("name","Ram");
     		reqData.put("job","QA");
     		given()		
     		 	.body(reqData.toJSONString())
     	   .when()
     			.patch("/users/" + userID)
     	   .then()
     		   .statusCode(200)
     		   .log().body();
     		System.out.println(userID + " : Updated Successfully");	
     		
     		try {
//        >+++++++++++++++++++ updated or not++++++++++++++++++++<
     			given()
     				.get("/users/" + userID).
     			then()
     				.statusCode(200)
     				.body("data.id", equalTo(4))
     				.log().body();
     		} catch (Exception e) {
     			
     		}
     		
//    >+++++++++++++delete same user >> validate code >> search user >> validate+++++++++++++++++<
     	   when()
     		.delete("/users/" + userID)
     	.then()
     		.statusCode(204)
     		.log().ifStatusCodeIsEqualTo(204);
     	System.out.println(userID + " : Deleted Successful");
     	
//        >+++++++++++++++ deleted or not+++++++++++++++++++<
     			given()
     				.get("/users/" + userID)
     		   .then()
     				.statusCode(200)
     				.log().everything()   
  				    .log().body();
     		
           
    
	}

	

}
