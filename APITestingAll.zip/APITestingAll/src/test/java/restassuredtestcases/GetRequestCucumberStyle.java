package restassuredtestcases;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;

import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
public class GetRequestCucumberStyle {
	
//  >===============GET LIST USERS =============<
	
	
	@Test (priority = 1,enabled = false)
	public void testGetUserList() {
		
		System.out.println("===============Test1=============");
		
		baseURI = "https://reqres.in/api";
//		Response rsp = get("https://reqres.in/api/users?page=2");
		
		given()
		    .get("/users?/page=2")
	    .then()
	        .statusCode(200)
	        .log().all();
		
	}
	
//  >===============GET SINGLE USER =============<
	
	@Test(priority = 2)
	public void testValidateGetUserlistData () {
		
		System.out.println("===============Test2=============");
		
		baseURI = "https://reqres.in/api";
		
		given()
	        .get("/users=2")
        .then()
            .statusCode(200)
		    //.log().body()
		    //.log().headers()
		    .log().everything()	
		    //.log().status()
		    .log().ifStatusCodeIsEqualTo(200)
		    .log().ifValidationFails(LogDetail.STATUS);
		    //.log().all();
  }
	
	
//  >===============GET SINGLE USER NOT FOUND=============<
	
	@Test(priority = 3,enabled = true)
	public void testGetSingleUsersNotFound() {
		
		System.out.println("===============Test3=============");
		
		baseURI = "https://reqres.in/api";

		
		given()
		    .get("/users/23")
	    .then()
	        .statusCode(404)
	        .log().headers()
	        .log().body()
	        .log().status()
		    .log().ifStatusCodeIsEqualTo(404);
		
	
	}
	
//  >===============GET LIST <RESOURCE>=============<
	
	@Test(priority = 4)
	public void testGetUsersListResourc() {
		
		System.out.println("===============Test4=============");
		
		baseURI = "https://reqres.in/api";

		
		given()
		    .get("/unknown")
	    .then()
	        .statusCode(200)
	        //.log().headers()
	        //.log().body()
	        //.log().status()
	        .log().all();
		
	
	}
	
	
//  >===============GET SINGLE <RESOURCE>=============<
	
	@Test(priority = 5)
	public void testGetSingleUsersResource() {
		
		System.out.println("===============Test5=============");
		
		baseURI = "https://reqres.in/api";

		
		given()
		    .get("/unknown/2")
	    .then()
	        .statusCode(200)
	        .body("data.id", equalTo(2))
	        .body("data.name", equalTo("fuchsia rose"))
	        .log().headers()
	        .log().body()
	        .log().ifValidationFails(LogDetail.STATUS)
	        .log().status();
		
	
	}
	
	
//  >===============GET SINGLE <RESOURCE> NOT FOUND=============<

	@Test(priority = 6)
	public void testGetSingleResourceNotFoun() {
		
		System.out.println("===============Test6=============");
		
		baseURI = "https://reqres.in/api";

		
		given()
		    .get("/unknown/23")
		    
	    .then()
	        .statusCode(404)
	        //.log().headers()
	        //.log().body()
	        .log().all();
		
	
	}
}
