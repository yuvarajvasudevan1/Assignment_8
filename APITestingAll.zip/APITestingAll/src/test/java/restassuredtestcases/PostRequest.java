package restassuredtestcases;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;
public class PostRequest {

//    >===============POST CREATE=============<	
	
	@Test(priority = 1)
	public void testPostCreateUser() {
		
		System.out.println("===============Test1=============");
		
		baseURI = "https://reqres.in/api";
		
	    JSONObject reqData = new JSONObject();
	    
        reqData.put("name", "John");
        reqData.put("job", "Teacher");
        
        System.out.println(reqData.toJSONString());
        
        given()
            //.header("Content-Type", "application/json")
            .header("Connection", "keep-alive")
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON)
            .body(reqData.toJSONString())
       .when()
            .post("/users")
        .then()
            .statusCode(201)
            .log().status()
            .log().body();
	}
	
//	  >===============POST REGISTER -UNSUCCESSFUL=============<
	
	@Test(priority = 2)
	public void testPostRegisterUnSuccessful() {
		
		System.out.println("===============Test2=============");
		
		baseURI = "https://reqres.in/api";
		
	    JSONObject reqData = new JSONObject();
	    
        reqData.put("email", "eve.holt@reqres.in");
       // reqData.put("password", "Raj");
        
        System.out.println(reqData.toJSONString());
        
        given()
            .header("Connection", "keep-alive")
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON)
            .body(reqData.toJSONString())
       .when()
            .post("/register")
        .then()
            .statusCode(400)
            .log().body();
	}	
	
//    >===============POST REGISTER -SUCCESSFUL=============<
	
	@Test(priority = 3)
	public void testPostRegisterSuccessfll() {
		
		System.out.println("===============Test3=============");
		
		baseURI = "https://reqres.in/api";
		
	    JSONObject reqData = new JSONObject();
	    
        reqData.put("email", "eve.holt@reqres.in");
        reqData.put("password", "Raj");
        
        System.out.println(reqData.toJSONString());
        
        given()
            .header("Connection", "keep-alive")
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON)
            .body(reqData.toJSONString())
       .when()
            .post("/register")
        .then()
            .statusCode(200)
            .log().ifValidationFails(LogDetail.STATUS)
            .log().body();
}
	
//    >===============POST LOGIN -UNSUCCESSFUL=============<
	
	@Test(priority = 4)
	public void testPostLogInUnSuccessfll() {
		
		System.out.println("===============Test4=============");
		
		baseURI = "https://reqres.in/api";
		
	    JSONObject reqData = new JSONObject();
	    
        reqData.put("email", "yuvaraj@gmai.com");
        //reqData.put("password", "ram");
        
        System.out.println(reqData.toJSONString());
        
        given()
            .header("Connection", "keep-alive")
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON)
            .body(reqData.toJSONString())
    		
       .when()
            .post("/login")
        .then()
            .statusCode(400)
            .log().body()
            .log().ifStatusCodeIsEqualTo(400);
}
	
//  >===============POST LOGIN -SUCCESSFUL=============<
	
	@Test(priority = 5)
	public void testPostLogInSuccessfll() {
		
		System.out.println("===============Test5=============");
		
		baseURI = "https://reqres.in/api";
		
	    JSONObject reqData = new JSONObject();
	    
        reqData.put("email", "eve.holt@reqres.in");
        reqData.put("password", "cityslicka");
        
        System.out.println(reqData.toJSONString());
        
        given()
           
            .header("Connection", "keep-alive")
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON)
            .body(reqData.toJSONString())
    		
       .when()
            .post("/login")
        .then()
            .statusCode(200)
            .log().body()
            .log().everything()
            .log().status();
	}	
}
